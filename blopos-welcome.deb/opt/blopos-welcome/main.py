import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk
import webbrowser

class Handler:

    def onButtonPressed(self, widget):
        url = 'https://bf228-fnf.github.io/blopos/htib.html'
        webbrowser.open(url)

    def onButton2Pressed(self, button):
        url = 'https://bf228-fnf.github.io/blopos/pnbo.html'
        webbrowser.open(url)

    def onButton3Pressed(self, button):
        url = 'https://bf228-fnf.github.io/blopos/htub.html'
        webbrowser.open(url)

    def onButton4Pressed(self, button):
        url = 'https://bf228-fnf.github.io/blopos/htipw.html'
        webbrowser.open(url)

builder = Gtk.Builder()
builder.add_from_file("welcome.glade")
builder.connect_signals(Handler())

window = builder.get_object("window1")
window.show_all()

Gtk.main()